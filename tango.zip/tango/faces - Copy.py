# -*- coding: utf-8 -*-
"""
Created on Thu Jul 26 16:51:23 2018

@author: Shreyas
"""

import urllib
import cv2
import numpy as np
import urllib.request
import pickle
import time
import datetime
time = datetime.datetime.now()

def save_im(n):
    img_item = 'image{}.jpg'.format(n)
    cv2.imwrite(img_item, roi_color)
    #time.sleep(1)
    

face_cascade = cv2.CascadeClassifier('cascades/data/haarcascade_frontalface_alt2.xml')
eye_cascade = cv2.CascadeClassifier('cascades/data/haarcascade_eye.xml')
smile_cascade = cv2.CascadeClassifier('cascades/data/haarcascade_smile.xml')

url = 'http://192.168.10.150:8080/shot.jpg?rnd=453229'
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read("face-trainner.yml")

labels = {"person_name": 1}
with open("pickles/face-labels.pickle", 'rb') as f:
	og_labels = pickle.load(f)
	labels = {v:k for k,v in og_labels.items()}

i = u = 0
while(True):
    with urllib.request.urlopen(url) as u:
        cap = u.read()
    # Numpy to convert into a array
    imgNp = np.array(bytearray(cap),dtype=np.uint8)
    
    # Finally decode the array to OpenCV usable format ;) 
    frame = cv2.imdecode(imgNp,-1)
    gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.5, minNeighbors=5)
    print(faces)
    for (x, y, w, h) in faces:
        i = i+1
        	#print(x,y,w,h)
        roi_gray = gray[y:y+h, x:x+w] #(ycord_start, ycord_end)
        roi_color = frame[y:y+h, x:x+w]        

        # recognize? deep learned model predict keras tensorflow pytorch scikit learn
        id_, conf = recognizer.predict(roi_gray)
        if conf>=90 : #and conf <= 85:
            #print(5: #id_)
            #print(labels[id_])
            print(time)
            font = cv2.FONT_HERSHEY_SIMPLEX
            name = labels[id_]
            color = (255, 255, 255)
            stroke = 2
        else :
           name = 'user-{}'.format(u)
        cv2.putText(frame, name, (x,y), font, 1, color, stroke, cv2.LINE_AA)
        color = (255, 0, 0) #BGR 0-255 
        stroke = 2
        end_cord_x = x + w
        end_cord_y = y + h
        cv2.rectangle(frame, (x, y), (end_cord_x, end_cord_y), color, stroke)
        save_im(i)
    # Display the resulting frame
    cv2.imshow('frame',frame)
    if cv2.waitKey(20) & 0xFF == ord('q'):
        break

# When everything done, release the capture
cv2.destroyAllWindows()